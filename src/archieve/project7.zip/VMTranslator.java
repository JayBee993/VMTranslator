import java.io.IOException;
import java.nio.file.Path;

public class VMTranslator {
	
	// Compile the code first via cmd with
	// javac VMTranslator.java


    public static void main(String[] args) throws IOException {

        if (args.length != 1) {
            System.err.println("Usage: java VMTranslator <input.vm>");
            System.exit(1);
        }

        Path inputPath = Path.of(args[0]);

        if (!inputPath.toString().endsWith(".vm")) {
            System.err.println("Input file must end with .vm");
            System.exit(1);
        }

        Path outputPath = Path.of(
            inputPath.toString().replace(".vm", ".asm")
        );

        Parser parser = new Parser(inputPath.toString());
        CodeWriter writer = new CodeWriter(outputPath);

        while (parser.hasMoreLines()) {
            parser.advance();
            writer.write(parser.currentCommand());
        }

        writer.close();
    }
}

	
		
//		List<String> files = List.of("BasicTest","PointerTest","SimpleAdd","StackTest","StaticTest");
//		
//		List<String> files = List.of("PointerTest");
//		
//		for(String file : files) {
//			
//			String filePath = "C:\\Nand2Tetris\\Project07\\VMFilestoTranslate\\"+ file +".vm";
//			String outputPath = "C:\\Nand2Tetris\\Project07\\VMFilestoTranslate\\"+ file +".asm";
//			
//			System.out.println(filePath);
//			
//			Parser testParser = new Parser(filePath);
//			CodeWriter testWriter = new CodeWriter(Path.of(outputPath));
//			
//			
//			while( testParser.hasMoreLines()) {
//				testParser.advance();
//				testWriter.write(testParser.currentCommand());
//			}
//			testWriter.close();
//		}
//
//	}
			
//}
		
//		String filePath = "C:\\Nand2Tetris\\Project07\\VMTranslator\\src\\Test.vm";
//		String outputPath = "C:\\Nand2Tetris\\Project07\\VMTranslator\\src\\Test1111.asm";
		

//		Parser testParser = new Parser(filePath);
//		CodeWriter testWriter = new CodeWriter(Path.of(outputPath));
//		
//		
//		while( testParser.hasMoreLines()) {
//			testParser.advance();
//			testWriter.write(testParser.currentCommand());
//		}
//		testWriter.close();
//	}

