
public record VMCommand(CommandType commandType, MemorySegment memorySegment, Integer location, ArithmeticOperation arithmeticOperation) {

}
