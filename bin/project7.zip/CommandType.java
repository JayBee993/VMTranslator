
public enum CommandType {
	C_ARITHMETIC,
	C_PUSH,
	C_POP
}
